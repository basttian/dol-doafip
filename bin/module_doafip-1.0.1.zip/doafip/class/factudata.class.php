<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file        class/factudata.class.php
 * \ingroup     doafip
 * \brief       This file is a CRUD class file for FactuData (Create/Read/Update/Delete)
 */

// Put here all includes required by your class file
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';
//require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
//require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

/**
 * Class for FactuData
 */
class FactuData extends CommonObject
{
	/**
	 * @var string ID of module.
	 */
	public $module = 'doafip';

	/**
	 * @var string ID to identify managed object.
	 */
	public $element = 'factudata';

	/**
	 * @var string Name of table without prefix where object is stored. This is also the key used for extrafields management.
	 */
	public $table_element = 'doafip_factudata';

	/**
	 * @var int  Does this object support multicompany module ?
	 * 0=No test on entity, 1=Test with field entity, 'field@table'=Test with link by field@table
	 */
	public $ismultientitymanaged = 0;

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 1;

	/**
	 * @var string String with name of icon for factudata. Must be the part after the 'object_' into object_factudata.png
	 */
	public $picto = 'factudata@doafip';


	const STATUS_DRAFT = 0;
	const STATUS_VALIDATED = 1;
	const STATUS_CANCELED = 9;

	/**
	 *  'type' field format ('integer', 'integer:ObjectClass:PathToClass[:AddCreateButtonOrNot[:Filter]]', 'sellist:TableName:LabelFieldName[:KeyFieldName[:KeyFieldParent[:Filter]]]', 'varchar(x)', 'double(24,8)', 'real', 'price', 'text', 'text:none', 'html', 'date', 'datetime', 'timestamp', 'duration', 'mail', 'phone', 'url', 'password')
	 *         Note: Filter can be a string like "(t.ref:like:'SO-%') or (t.date_creation:<:'20160101') or (t.nature:is:NULL)"
	 *  'label' the translation key.
	 *  'picto' is code of a picto to show before value in forms
	 *  'enabled' is a condition when the field must be managed (Example: 1 or '$conf->global->MY_SETUP_PARAM)
	 *  'position' is the sort order of field.
	 *  'notnull' is set to 1 if not null in database. Set to -1 if we must set data to null if empty ('' or 0).
	 *  'visible' says if field is visible in list (Examples: 0=Not visible, 1=Visible on list and create/update/view forms, 2=Visible on list only, 3=Visible on create/update/view form only (not list), 4=Visible on list and update/view form only (not create). 5=Visible on list and view only (not create/not update). Using a negative value means field is not shown by default on list but can be selected for viewing)
	 *  'noteditable' says if field is not editable (1 or 0)
	 *  'default' is a default value for creation (can still be overwrote by the Setup of Default Values if field is editable in creation form). Note: If default is set to '(PROV)' and field is 'ref', the default value will be set to '(PROVid)' where id is rowid when a new record is created.
	 *  'index' if we want an index in database.
	 *  'foreignkey'=>'tablename.field' if the field is a foreign key (it is recommanded to name the field fk_...).
	 *  'searchall' is 1 if we want to search in this field when making a search from the quick search button.
	 *  'isameasure' must be set to 1 if you want to have a total on list for this field. Field type must be summable like integer or double(24,8).
	 *  'css' and 'cssview' and 'csslist' is the CSS style to use on field. 'css' is used in creation and update. 'cssview' is used in view mode. 'csslist' is used for columns in lists. For example: 'css'=>'minwidth300 maxwidth500 widthcentpercentminusx', 'cssview'=>'wordbreak', 'csslist'=>'tdoverflowmax200'
	 *  'help' is a 'TranslationString' to use to show a tooltip on field. You can also use 'TranslationString:keyfortooltiponlick' for a tooltip on click.
	 *  'showoncombobox' if value of the field must be visible into the label of the combobox that list record
	 *  'disabled' is 1 if we want to have the field locked by a 'disabled' attribute. In most cases, this is never set into the definition of $fields into class, but is set dynamically by some part of code.
	 *  'arrayofkeyval' to set a list of values if type is a list of predefined values. For example: array("0"=>"Draft","1"=>"Active","-1"=>"Cancel"). Note that type can be 'integer' or 'varchar'
	 *  'autofocusoncreate' to have field having the focus on a create form. Only 1 field should have this property set to 1.
	 *  'comment' is not used. You can store here any text of your choice. It is not used by application.
	 *
	 *  Note: To have value dynamic, you can set value to 0 in definition and edit the value on the fly into the constructor.
	 */

	// BEGIN MODULEBUILDER PROPERTIES
	/**
	 * @var array  Array with all fields and their property. Do not use it as a static var. It may be modified by constructor.
	 */
	public $fields=array(
		'rowid' => array('type'=>'integer', 'label'=>'TechnicalID', 'enabled'=>'1', 'position'=>1, 'notnull'=>1, 'visible'=>0, 'noteditable'=>'1', 'index'=>1, 'css'=>'left', 'comment'=>"Id"),
		'ref' => array('type'=>'varchar(128)', 'label'=>'Ref', 'enabled'=>'1', 'position'=>20, 'notnull'=>1, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'comment'=>"Reference of object"),
		'fk_soc' => array('type'=>'integer:Societe:societe/class/societe.class.php:1:status=1 AND entity IN (__SHARED_ENTITIES__)', 'label'=>'ThirdParty', 'enabled'=>'1', 'position'=>50, 'notnull'=>-1, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'help'=>"LinkToThirparty",),
		'fk_project' => array('type'=>'integer:Project:projet/class/project.class.php:1', 'label'=>'Project', 'enabled'=>'1', 'position'=>52, 'notnull'=>-1, 'visible'=>-1, 'noteditable'=>'1', 'index'=>1,),
		'note_public' => array('type'=>'html', 'label'=>'NotePublic', 'enabled'=>'1', 'position'=>61, 'notnull'=>0, 'visible'=>0,),
		'note_private' => array('type'=>'html', 'label'=>'NotePrivate', 'enabled'=>'1', 'position'=>62, 'notnull'=>0, 'visible'=>0,),
		'date_creation' => array('type'=>'datetime', 'label'=>'DateCreation', 'enabled'=>'1', 'position'=>500, 'notnull'=>1, 'visible'=>-2,),
		'tms' => array('type'=>'timestamp', 'label'=>'DateModification', 'enabled'=>'1', 'position'=>501, 'notnull'=>0, 'visible'=>-2,),
		'fk_user_creat' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserAuthor', 'enabled'=>'1', 'position'=>510, 'notnull'=>-1, 'visible'=>-2,),
		'fk_user_modif' => array('type'=>'integer:User:user/class/user.class.php', 'label'=>'UserModif', 'enabled'=>'1', 'position'=>511, 'notnull'=>-1, 'visible'=>-2,),
		'last_main_doc' => array('type'=>'varchar(255)', 'label'=>'LastMainDoc', 'enabled'=>'1', 'position'=>600, 'notnull'=>0, 'visible'=>0,),
		'import_key' => array('type'=>'varchar(14)', 'label'=>'ImportId', 'enabled'=>'1', 'position'=>1000, 'notnull'=>-1, 'visible'=>-2,),
		'model_pdf' => array('type'=>'varchar(255)', 'label'=>'Model pdf', 'enabled'=>'1', 'position'=>1010, 'notnull'=>-1, 'visible'=>0,),
		'status' => array('type'=>'smallint', 'label'=>'Status', 'enabled'=>'1', 'position'=>1000, 'notnull'=>1, 'visible'=>1, 'index'=>1, 'arrayofkeyval'=>array('0'=>'Borrador', '1'=>'Validado', '9'=>'Cancelado'),),
		'CantReg' => array('type'=>'integer', 'label'=>'CantReg', 'enabled'=>'1', 'position'=>10001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"CantReg"),
		'PtoVta' => array('type'=>'integer', 'label'=>'PtoVta', 'enabled'=>'1', 'position'=>10002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"PtoVta"),
		'CbteTipo' => array('type'=>'integer', 'label'=>'CbteTipo', 'enabled'=>'1', 'position'=>10003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"CbteTipo"),
		'Concepto' => array('type'=>'integer', 'label'=>'Concepto', 'enabled'=>'1', 'position'=>10004, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Concepto"),
		'DocTipo' => array('type'=>'integer', 'label'=>'DocTipo', 'enabled'=>'1', 'position'=>10005, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"DocTipo"),
		'DocNro' => array('type'=>'integer', 'label'=>'DocNro', 'enabled'=>'1', 'position'=>10006, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"DocNro"),
		'CbteDesde' => array('type'=>'integer', 'label'=>'CbteDesde', 'enabled'=>'1', 'position'=>10007, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"CbteDesde"),
		'CbteHasta' => array('type'=>'integer', 'label'=>'CbteHasta', 'enabled'=>'1', 'position'=>10008, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"CbteHasta"),
		'CbteFch' => array('type'=>'varchar(255)', 'label'=>'CbteFch', 'enabled'=>'1', 'position'=>10009, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"CbteFch"),
		'ImpTotal' => array('type'=>'double(24,2)', 'label'=>'ImpTotal', 'enabled'=>'1', 'position'=>10010, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpTotal"),
		'ImpTotConc' => array('type'=>'double(24,2)', 'label'=>'ImpTotConc', 'enabled'=>'1', 'position'=>10011, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpTotConc"),
		'ImpNeto' => array('type'=>'double(24,2)', 'label'=>'ImpNeto', 'enabled'=>'1', 'position'=>10012, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpNeto"),
		'ImpOpEx' => array('type'=>'double(24,2)', 'label'=>'ImpOpEx', 'enabled'=>'1', 'position'=>10013, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpOpEx"),
		'ImpIVA' => array('type'=>'double(24,2)', 'label'=>'ImpIVA', 'enabled'=>'1', 'position'=>10014, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpIVA"),
		'ImpTrib' => array('type'=>'double(24,2)', 'label'=>'ImpTrib', 'enabled'=>'1', 'position'=>10015, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"ImpTrib"),
		'FchServDesde' => array('type'=>'varchar(255)', 'label'=>'FchServDesde', 'enabled'=>'1', 'position'=>10016, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"FchServDesde"),
		'FchServHasta' => array('type'=>'varchar(255)', 'label'=>'FchServHasta', 'enabled'=>'1', 'position'=>10017, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"FchServHasta"),
		'FchVtoPago' => array('type'=>'varchar(255)', 'label'=>'FchVtoPago', 'enabled'=>'1', 'position'=>10018, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"FchVtoPago"),
		'MonId' => array('type'=>'varchar(128)', 'label'=>'MonId', 'enabled'=>'1', 'position'=>10019, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"MonId"),
		'MonCotiz' => array('type'=>'integer', 'label'=>'MonCotiz', 'enabled'=>'1', 'position'=>10020, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"MonCotiz"),
		'CbtesAsocTipo' => array('type'=>'integer', 'label'=>'CbtesAsocTipo', 'enabled'=>'1', 'position'=>20001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprobante Asoc -Tipo de comprobante (ver tipos disponibles)"),
		'CbtesAsocPtoVta' => array('type'=>'integer', 'label'=>'CbtesAsocPtoVta', 'enabled'=>'1', 'position'=>20002, 'notnull'=>0, 'visible'=>-1, 'noteditable'=>'1', 'comment'=>"Comprobante Asoc - Punto de venta"),
		'CbtesAsocNro' => array('type'=>'integer', 'label'=>'CbtesAsocNro', 'enabled'=>'1', 'position'=>20003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprobante Asoc - Numero de comprobante"),
		'CbtesAsocCuit' => array('type'=>'varchar(11)', 'label'=>'CbtesAsocCuit', 'enabled'=>'1', 'position'=>20004, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprobante Asoc - Cuit del emisor del comprobante"),
		'TributosId' => array('type'=>'integer', 'label'=>'TributosId', 'enabled'=>'1', 'position'=>30001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Tributos - Id del tipo de tributo"),
		'TributosDesc' => array('type'=>'varchar(80)', 'label'=>'TributosDesc', 'enabled'=>'1', 'position'=>30002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Tributos - Descripción del tributo"),
		'TributosBaseImp' => array('type'=>'double(24,2)', 'label'=>'TributosBaseImp', 'enabled'=>'1', 'position'=>30003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Tributos - Base imponible para el tributo"),
		'TributosAlic' => array('type'=>'double(24,2)', 'label'=>'TributosAlic', 'enabled'=>'1', 'position'=>30004, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Tributos - Alicuota"),
		'TributosImporte' => array('type'=>'double(24,2)', 'label'=>'TributosImporte', 'enabled'=>'1', 'position'=>30005, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Tributos - Importe del tributo"),
		'IvaId' => array('type'=>'text', 'label'=>'IvaId', 'enabled'=>'1', 'position'=>40001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Iva - Id del tipo de IVA"),
		'IvaBaseImp' => array('type'=>'text', 'label'=>'IvaBaseImp', 'enabled'=>'1', 'position'=>40002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Iva - Base imponible"),
		'IvaImporte' => array('type'=>'text', 'label'=>'IvaImporte', 'enabled'=>'1', 'position'=>40003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Iva - Importe"),
		'OpcionalesId' => array('type'=>'integer', 'label'=>'OpcionalesId', 'enabled'=>'1', 'position'=>50001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Opcionales - Cosigo de opcional"),
		'OpcionalesValor' => array('type'=>'varchar(255)', 'label'=>'OpcionalesValor', 'enabled'=>'1', 'position'=>50002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Opcionales - Valor"),
		'CompradoresDocTipo' => array('type'=>'integer', 'label'=>'CompradoresDocTipo', 'enabled'=>'1', 'position'=>60001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprador - Tipo de Documento"),
		'CompradoresDocNro' => array('type'=>'varchar(80)', 'label'=>'CompradoresDocNro', 'enabled'=>'1', 'position'=>60002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprador - Numero de documento"),
		'CompradoresPorcentaje' => array('type'=>'double(24,2)', 'label'=>'CompradoresPorcentaje', 'enabled'=>'1', 'position'=>60003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Comprador - Porcentaje de titularidad del comprador"),
		'ResResultado' => array('type'=>'varchar(128)', 'label'=>'Resultado', 'enabled'=>'1', 'position'=>70001, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Resultado A Aprobado"),
		'ResCodAutorizacion' => array('type'=>'varchar(255)', 'label'=>'Cod. Autorizacion', 'enabled'=>'1', 'position'=>70002, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Resultado Cod. Autirizacion"),
		'ResEmisionTipo' => array('type'=>'varchar(128)', 'label'=>'Tipo de emision', 'enabled'=>'1', 'position'=>70003, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Resultado tipo de emision"),
		'ResFchVto' => array('type'=>'varchar(128)', 'label'=>'Fecha de vencimiento', 'enabled'=>'1', 'position'=>70004, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Respuesta Fecha de vencimiento"),
		'ResFchProceso' => array('type'=>'varchar(128)', 'label'=>'Fecha Proceso', 'enabled'=>'1', 'position'=>70005, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Respuesta fecha de proceso"),
		'ResBarCode' => array('type'=>'varchar(255)', 'label'=>'Cod. Barras', 'enabled'=>'1', 'position'=>70006, 'notnull'=>0, 'visible'=>1, 'noteditable'=>'1', 'index'=>1, 'searchall'=>1, 'css'=>'left', 'comment'=>"Codigo de Barras de Factura"),
		'fk_facture' => array('type'=>'integer:Facture:compta/facture/class/facture.class.php', 'label'=>'Id Factura', 'enabled'=>'1', 'position'=>10000, 'notnull'=>1, 'visible'=>1, 'noteditable'=>'1', 'comment'=>"Clave Foranea Factura"),
	);
	public $rowid;
	public $ref;
	public $fk_soc;
	public $fk_project;
	public $note_public;
	public $note_private;
	public $date_creation;
	public $tms;
	public $fk_user_creat;
	public $fk_user_modif;
	public $last_main_doc;
	public $import_key;
	public $model_pdf;
	public $status;
	public $CantReg;
	public $PtoVta;
	public $CbteTipo;
	public $Concepto;
	public $DocTipo;
	public $DocNro;
	public $CbteDesde;
	public $CbteHasta;
	public $CbteFch;
	public $ImpTotal;
	public $ImpTotConc;
	public $ImpNeto;
	public $ImpOpEx;
	public $ImpIVA;
	public $ImpTrib;
	public $FchServDesde;
	public $FchServHasta;
	public $FchVtoPago;
	public $MonId;
	public $MonCotiz;
	public $CbtesAsocTipo;
	public $CbtesAsocPtoVta;
	public $CbtesAsocNro;
	public $CbtesAsocCuit;
	public $TributosId;
	public $TributosDesc;
	public $TributosBaseImp;
	public $TributosAlic;
	public $TributosImporte;
	public $IvaId;
	public $IvaBaseImp;
	public $IvaImporte;
	public $OpcionalesId;
	public $OpcionalesValor;
	public $CompradoresDocTipo;
	public $CompradoresDocNro;
	public $CompradoresPorcentaje;
	public $ResResultado;
	public $ResCodAutorizacion;
	public $ResEmisionTipo;
	public $ResFchVto;
	public $ResFchProceso;
	public $ResBarCode;
	public $fk_facture;
	// END MODULEBUILDER PROPERTIES
	// If this object has a subtable with lines

	/**
	 * @var String CUIL/CUIT FROM CONFIG
	 * @return string 
	 */
	public $cuilit;
	// /**
	//  * @var string    Name of subtable line
	//  */
	// public $table_element_line = 'doafip_factudataline';

	// /**
	//  * @var string    Field with ID of parent key if this object has a parent
	//  */
	// public $fk_element = 'fk_factudata';

	// /**
	//  * @var string    Name of subtable class that manage subtable lines
	//  */
	// public $class_element_line = 'FactuDataline';

	// /**
	//  * @var array	List of child tables. To test if we can delete object.
	//  */
	// protected $childtables = array();

	// /**
	//  * @var array    List of child tables. To know object to delete on cascade.
	//  *               If name matches '@ClassNAme:FilePathClass;ParentFkFieldName' it will
	//  *               call method deleteByParentField(parentId, ParentFkFieldName) to fetch and delete child object
	//  */
	// protected $childtablesoncascade = array('doafip_factudatadet');

	// /**
	//  * @var FactuDataLine[]     Array of subtable lines
	//  */
	// public $lines = array();



	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
		global $conf, $langs;

		$this->db = $db;
		$this->cuilit = !empty($conf->global->MAIN_INFO_SIREN) ? $conf->global->MAIN_INFO_SIREN : '';

		if (empty($conf->global->MAIN_SHOW_TECHNICAL_ID) && isset($this->fields['rowid'])) {
			$this->fields['rowid']['visible'] = 0;
		}
		if (empty($conf->multicompany->enabled) && isset($this->fields['entity'])) {
			$this->fields['entity']['enabled'] = 0;
		}

		// Example to show how to set values of fields definition dynamically
		//if ($user->rights->doafip->factudata->read) {
			//$this->fields['myfield']['visible'] = 1;
			//$this->fields['myfield']['noteditable'] = 0;
		//}

		// Unset fields that are disabled
		foreach ($this->fields as $key => $val) {
			if (isset($val['enabled']) && empty($val['enabled'])) {
				unset($this->fields[$key]);
			}
		}

		// Translate some data of arrayofkeyval
		if (is_object($langs)) {
			foreach ($this->fields as $key => $val) {
				if (!empty($val['arrayofkeyval']) && is_array($val['arrayofkeyval'])) {
					foreach ($val['arrayofkeyval'] as $key2 => $val2) {
						$this->fields[$key]['arrayofkeyval'][$key2] = $langs->trans($val2);
					}
				}
			}
		}
	}
	
	
	
	/**
	 * Create Facture Afip
	 * @param array $data
	 * @param int $socid
	 * @param int $factid
	 * @return resource line in db
	 */
	
	public function createFactureAfip(User $user, $data = array(), $socid, $factid){
	    //$mysqli = new mysqli("localhost", "root", "", "doli-afip");
	    //global $db;
        $arrIvaId = array();
        $arrIvaBaseImp = array();
        $arrIvaImporte = array();
        
	    $this->db->begin();
	    if (!empty($data)) {
	        
	         for($i=0; $i<count($data['Iva'][0]);$i++){
	           $arrIvaId[] = $data['Iva'][$i]['Id'];
	           $arrIvaBaseImp[] = $data['Iva'][$i]['BaseImp'];
	           $arrIvaImporte[] = $data['Iva'][$i]['Importe'];
	         };
	         $ivaId=implode(',', $arrIvaId);
	         $ivaBase=implode(',', $arrIvaBaseImp);
	         $ivaImporte=implode(',', $arrIvaImporte);
	        
	        $sql = 'INSERT INTO '.MAIN_DB_PREFIX.$this->table_element;
	        $sql.= '(ref,
                    fk_soc,
                    status,
                    fk_project,
                    fk_user_creat,
                    fk_user_modif,
                    fk_facture,
                    CantReg,
                    PtoVta,
                    CbteTipo,
                    Concepto,
                    DocTipo,
                    DocNro,
                    CbteDesde,
                    CbteHasta,
                    CbteFch,
                    ImpTotal,
                    ImpTotConc,
                    ImpNeto,
                    ImpOpEx,
                    ImpIVA,
                    ImpTrib,
                    FchServDesde,
                    FchServHasta,
                    FchVtoPago,
                    MonId,
                    MonCotiz,
                    CbtesAsocTipo,
                    CbtesAsocPtoVta,
                    CbtesAsocNro,
                    CbtesAsocCuit,
                    TributosId,
                    TributosDesc,
                    TributosBaseImp,
                    TributosAlic,
                    TributosImporte,
                    IvaId,
                    IvaBaseImp,
                    IvaImporte,
                    OpcionalesId,
                    OpcionalesValor,
                    CompradoresDocTipo,
                    CompradoresDocNro,
                    CompradoresPorcentaje,
                    ResResultado,
                    ResCodAutorizacion,
                    ResEmisionTipo,
                    ResFchVto,
                    ResFchProceso,
                    ResBarCode)VALUES( 
                                   '.(!empty($data['CbteDesde'])?$data['CbteDesde']:"null").', /*ref voucher*/
                                   '. $socid.',
                                   0,
                                   '.($this->fk_project ? $this->fk_project : "null").',
                                   '.((int)$user->id).',
                                   '.((int)$user->id).',
                                   '. $factid.',
                                   '.(!empty($data['CantReg'])?$data['CantReg']:"null").',
                                   '.(!empty($data['PtoVta'])?$data['PtoVta']:"null").',
                                   '.(!empty($data['CbteTipo'])?$data['CbteTipo']:"null").',
                                   '.(!empty($data['Concepto'])?$data['Concepto']:"null").',
                                   '.(!empty($data['DocTipo'])?$data['DocTipo']:"null").',
                                   '.(!empty($data['DocNro'])?$data['DocNro']:0).',
                                   '.(!empty($data['CbteDesde'])?$data['CbteDesde']:"null").',
                                   '.(!empty($data['CbteHasta'])?$data['CbteHasta']:"null").',
                                   '.(!empty($data['CbteFch'])?$data['CbteFch']:"null").',
                                   '.(!empty($data['ImpTotal'])?$data['ImpTotal']:"null").',
                                   '.(!empty($data['ImpTotConc'])?$data['ImpTotConc']:"null").',
                                   '.(!empty($data['ImpNeto'])?$data['ImpNeto']:"null").',
                                   '.(!empty($data['ImpOpEx'])?$data['ImpOpEx']:"null").',
                                   '.(!empty($data['ImpIVA'])?$data['ImpIVA']:"null").',
                                   '.(!empty($data['ImpTrib'])?$data['ImpTrib']:"null").',
                                   '.(!empty($data['FchServDesde'])?$data['FchServDesde']:"null").',
                                   '.(!empty($data['FchServHasta'])?$data['FchServHasta']:"null").',
                                   '.(!empty($data['FchVtoPago'])?$data['FchVtoPago']:"null").',
                                   "'.(!empty($data['MonId'])?$data['MonId']:"null").'",
                                   '.(!empty($data['MonCotiz'])?$data['MonCotiz']:"null").',
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    '.(!empty($data['Iva'])?sprintf("'%s'\n",$ivaId):"null").',
                                    '.(!empty($data['Iva'])?sprintf("'%s'\n",$ivaBase):"null").',
                                    '.(!empty($data['Iva'])?sprintf("'%s'\n",$ivaImporte):"null").',
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null,
                                    null )';
	        //print $sql;
	        //exit;
	        $resql = $this->db->query($sql);
	        if ($resql) {
	            $this->db->commit();
	        } else {
	            $this->db->rollback();
	            dol_print_error($this->db);
	        }  
	    }
	}
	
	/**
	 * 
	 * @param User $user
	 * @param integer $valFacId id-voucher
	 * @param string  $ResResultado
	 * @param string  $ResCodAutorizacion
	 * @param string  $ResEmisionTipo
	 * @param string  $ResFchVto
	 * @param string  $ResFchProceso
	 * @param string  $ResBarCode
	 * @return resource
	 */
	
	public function updateFactureAfip(User $user, $valFacId ,$ResResultado,$ResCodAutorizacion,$ResEmisionTipo,$ResFchVto,$ResFchProceso,$ResBarCode ) {
	    $this->db->begin();
	    if (!empty($ResResultado)) {
	        $sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
	        $sql .= " SET";
	        $sql .= " ResResultado = '".$ResResultado."',";
	        $sql .= " ResCodAutorizacion = '".$ResCodAutorizacion."',";
	        $sql .= " ResEmisionTipo = '".$ResEmisionTipo."',";
	        $sql .= " ResFchVto = '".$ResFchVto."',";
	        $sql .= " ResFchProceso = '".$ResFchProceso."',";
	        $sql .= " ResBarCode = $ResBarCode ";
	        $sql .= " WHERE ref = ".$valFacId ;
	        $resql = $this->db->query($sql);
	        if ($resql) {
	            $this->db->commit();
	        } else {
	            $this->db->rollback();
	            dol_print_error($this->db);
	        }
	    }
	}
	
	/**
	 * 
	 * @param string $codigo
	 * @return string barcode
	 */
	
	public function verificadorBase10($codigo){
	    $splitCodigo = str_split($codigo);
	    $bandera = true;
	    $sumaPar = 0;
	    $sumaImpar = 0;
	    foreach ($splitCodigo as $value) {
	        switch ($bandera) {
	            case true:
	                $sumaImpar += $value;
	                $bandera = false;
	                break;
	            case false:
	                $sumaPar += $value;
	                $bandera = true;
	                break;
	        }
	    }
	    $etapa2 = $sumaImpar * 3;
	    $etapa4 = $etapa2 + $sumaPar;
	    
	    $res = ($etapa4 % 10);
	    if($res == 0){
	        $codigoFinal = 0;
	        $cadenaFinal = ''.$codigo.$codigoFinal.'';
	        
	    }
	    if($res != 0){
	        $codigoFinal = 10 - $res;
	        $cadenaFinal = ''.$codigo.$codigoFinal.'';
	    }
	    
	    return $cadenaFinal;
	}
	
	/**
	 * 
	 * @param int $x tva 21, 10.5, 27 etc
	 * 
	 * @return number cod
	 */
	
	public function tipoIva($x){
	    switch(round($x,2)) {
	       case 0:
	           return 3;
	           break;
	       case 10.50:
	           return 4;
	           break;
	       case 21.00:
	           return 5;
	           break;
	       case 27.00:
	           return 6;
	           break;
	       case 5.00:
	           return 8;
	           break;
	       case 2.50:
	           return 9;
	           break;
	   }
	}
	
	/**
	 * 
	 * @param int $idFacture
	 * @return int Object id
	 */

	public function factureDataIdExtrafieldRef($idFacture) {
	    $this->db->begin();
	    $query = "select rowid from ".MAIN_DB_PREFIX."doafip_factudata where fk_facture = ".$idFacture." " ;
	    $resp = $this->db->query($query);
	    $object = $this->db->fetch_object($resp);
	    $this->db->commit();
	    if ($resp) {
	        return $object->rowid;
	    } else {
	        $this->db->rollback();
	        return false;
	    }
	}
	
	/**
	 * 
	 * @param int $factId
	 * @return resource Save data in facture extrafields
	 */
	
	public function addExtrafieldsFactureData($factId,$voucherNumber){
	    $value = $this->factureDataIdExtrafieldRef($factId);
	    $this->db->begin();
	    $query = 'INSERT INTO '.MAIN_DB_PREFIX.'facture_extrafields';
	    $query .= ' (fk_object,fk_doafip,voucher_number)';
	    $query .= ' VALUES( '.(int)$factId.' , '.(int)$value.' , '.$voucherNumber.' )';
	    $resql=$this->db->query($query);
	    if ($resql) {
	        $this->db->commit();
	    } else {
	        $this->db->rollback();
	        dol_print_error($db);
	    }
	}
	
	/**
	 *
	 * @param int $fkFactureId
	 * @return boolean
	 */
	public function record_exists($fkFactureId) {
	    $this->db->begin();
	    $sql = 'SELECT *';
	    $sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
	    $sql .= ' WHERE t.fk_facture = '.((int) $fkFactureId);
	    $result = $this->db->query($sql);
	    if ($result) {
	        $this->db->commit();
	        if ($this->db->num_rows($result)){
	            return true;
	        } else {
	            return false;
	        }
	    }
	}
	
	/**
	 * Search if voucher number exist in facture extrafields
	 * @param int $idFacture
	 * @param string $voucherNumber
	 * @return boolean
	 */
	
	public function voucher_exists($idFacture, $voucherNumber){
	    $this->db->begin();
	    $query = "SELECT fk_object, voucher_number from ".MAIN_DB_PREFIX."facture_extrafields WHERE fk_object = ".$idFacture." and voucher_number LIKE '%".trim($voucherNumber)."%'";
	    $result = $this->db->query($query);
	    if ($result) {
	        $this->db->commit();
	        if ($this->db->num_rows($result)){
	            return true;
	        } else {
	            return false;
	        }
	    }
	}
	
	/**
	 * 
	 * @param int $idFacture
	 * @return int idFactuData number
	 */
	public function searchIdAfipFromIdFacture($idFacture){
	    $this->db->begin();
	    $query = "SELECT fk_doafip FROM ".MAIN_DB_PREFIX."facture_extrafields WHERE fk_object = ".$idFacture." ";
	    $result = $this->db->query($query);
	    $this->db->commit();
	    if ($result) {
	        $obj = $this->db->fetch_object($result);
	        return $obj->fk_doafip;
	    } else {
	        dol_print_error($this->db);
	    }
	}
	
    /**
     * @param int $id
	 * @return int number siren doc
     */
    public function docSoc($id){
        $this->db->begin();
        $sql = "SELECT siren FROM ".MAIN_DB_PREFIX."societe WHERE rowid =  ".$id." ";
        $result = $this->db->query($sql);
	    $this->db->commit();
        if ($result) {
	        $obj = $this->db->fetch_object($result);
	        return $obj->siren;
	    } else {
	        dol_print_error($this->db);
	    }
    }
    
    
    
    
	/**
	 * Create object into database
	 *
	 * @param  User $user      User that creates
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, Id of created object if OK
	 */
	public function create(User $user, $notrigger = false)
	{
		$resultcreate = $this->createCommon($user, $notrigger);

		//$resultvalidate = $this->validate($user, $notrigger);

		return $resultcreate;
	}

	/**
	 * Clone an object into another one
	 *
	 * @param  	User 	$user      	User that creates
	 * @param  	int 	$fromid     Id of object to clone
	 * @return 	mixed 				New object created, <0 if KO
	 */
	public function createFromClone(User $user, $fromid)
	{
		global $langs, $extrafields;
		$error = 0;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$object = new self($this->db);

		$this->db->begin();

		// Load source object
		$result = $object->fetchCommon($fromid);
		if ($result > 0 && !empty($object->table_element_line)) {
			$object->fetchLines();
		}

		// get lines so they will be clone
		//foreach($this->lines as $line)
		//	$line->fetch_optionals();

		// Reset some properties
		unset($object->id);
		unset($object->fk_user_creat);
		unset($object->import_key);

		// Clear fields
		if (property_exists($object, 'ref')) {
			$object->ref = empty($this->fields['ref']['default']) ? "Copy_Of_".$object->ref : $this->fields['ref']['default'];
		}
		if (property_exists($object, 'label')) {
			$object->label = empty($this->fields['label']['default']) ? $langs->trans("CopyOf")." ".$object->label : $this->fields['label']['default'];
		}
		if (property_exists($object, 'status')) {
			$object->status = self::STATUS_DRAFT;
		}
		if (property_exists($object, 'date_creation')) {
			$object->date_creation = dol_now();
		}
		if (property_exists($object, 'date_modification')) {
			$object->date_modification = null;
		}
		// ...
		// Clear extrafields that are unique
		if (is_array($object->array_options) && count($object->array_options) > 0) {
			$extrafields->fetch_name_optionals_label($this->table_element);
			foreach ($object->array_options as $key => $option) {
				$shortkey = preg_replace('/options_/', '', $key);
				if (!empty($extrafields->attributes[$this->table_element]['unique'][$shortkey])) {
					//var_dump($key); var_dump($clonedObj->array_options[$key]); exit;
					unset($object->array_options[$key]);
				}
			}
		}

		// Create clone
		$object->context['createfromclone'] = 'createfromclone';
		$result = $object->createCommon($user);
		if ($result < 0) {
			$error++;
			$this->error = $object->error;
			$this->errors = $object->errors;
		}

		if (!$error) {
			// copy internal contacts
			if ($this->copy_linked_contact($object, 'internal') < 0) {
				$error++;
			}
		}

		if (!$error) {
			// copy external contacts if same company
			if (property_exists($this, 'fk_soc') && $this->fk_soc == $object->socid) {
				if ($this->copy_linked_contact($object, 'external') < 0) {
					$error++;
				}
			}
		}

		unset($object->context['createfromclone']);

		// End
		if (!$error) {
			$this->db->commit();
			return $object;
		} else {
			$this->db->rollback();
			return -1;
		}
	}

	/**
	 * Load object in memory from the database
	 *
	 * @param int    $id   Id object
	 * @param string $ref  Ref
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id, $ref = null)
	{
		$result = $this->fetchCommon($id, $ref);
		if ($result > 0 && !empty($this->table_element_line)) {
			$this->fetchLines();
		}
		return $result;
	}

	/**
	 * Load object lines in memory from the database
	 *
	 * @return int         <0 if KO, 0 if not found, >0 if OK
	 */
	public function fetchLines()
	{
		$this->lines = array();

		$result = $this->fetchLinesCommon();
		return $result;
	}


	/**
	 * Load list of objects in memory from the database.
	 *
	 * @param  string      $sortorder    Sort Order
	 * @param  string      $sortfield    Sort field
	 * @param  int         $limit        limit
	 * @param  int         $offset       Offset
	 * @param  array       $filter       Filter array. Example array('field'=>'valueforlike', 'customurl'=>...)
	 * @param  string      $filtermode   Filter mode (AND or OR)
	 * @return array|int                 int <0 if KO, array of pages if OK
	 */
	public function fetchAll($sortorder = '', $sortfield = '', $limit = 0, $offset = 0, array $filter = array(), $filtermode = 'AND')
	{
		global $conf;

		dol_syslog(__METHOD__, LOG_DEBUG);

		$records = array();

		$sql = 'SELECT ';
		$sql .= $this->getFieldList('t');
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		if (isset($this->ismultientitymanaged) && $this->ismultientitymanaged == 1) {
			$sql .= ' WHERE t.entity IN ('.getEntity($this->table_element).')';
		} else {
			$sql .= ' WHERE 1 = 1';
		}
		// Manage filter
		$sqlwhere = array();
		if (count($filter) > 0) {
			foreach ($filter as $key => $value) {
				if ($key == 't.rowid') {
					$sqlwhere[] = $key.'='.$value;
				} elseif (in_array($this->fields[$key]['type'], array('date', 'datetime', 'timestamp'))) {
					$sqlwhere[] = $key.' = \''.$this->db->idate($value).'\'';
				} elseif ($key == 'customsql') {
					$sqlwhere[] = $value;
				} elseif (strpos($value, '%') === false) {
					$sqlwhere[] = $key.' IN ('.$this->db->sanitize($this->db->escape($value)).')';
				} else {
					$sqlwhere[] = $key.' LIKE \'%'.$this->db->escape($value).'%\'';
				}
			}
		}
		if (count($sqlwhere) > 0) {
			$sql .= ' AND ('.implode(' '.$filtermode.' ', $sqlwhere).')';
		}

		if (!empty($sortfield)) {
			$sql .= $this->db->order($sortfield, $sortorder);
		}
		if (!empty($limit)) {
			$sql .= ' '.$this->db->plimit($limit, $offset);
		}

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			while ($i < ($limit ? min($limit, $num) : $num)) {
				$obj = $this->db->fetch_object($resql);

				$record = new self($this->db);
				$record->setVarsFromFetchObj($obj);

				$records[$record->id] = $record;

				$i++;
			}
			$this->db->free($resql);

			return $records;
		} else {
			$this->errors[] = 'Error '.$this->db->lasterror();
			dol_syslog(__METHOD__.' '.join(',', $this->errors), LOG_ERR);

			return -1;
		}
	}

	/**
	 * Update object into database
	 *
	 * @param  User $user      User that modifies
	 * @param  bool $notrigger false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function update(User $user, $notrigger = false)
	{
		return $this->updateCommon($user, $notrigger);
	}

	/**
	 * Delete object in database
	 *
	 * @param User $user       User that deletes
	 * @param bool $notrigger  false=launch triggers after, true=disable triggers
	 * @return int             <0 if KO, >0 if OK
	 */
	public function delete(User $user, $notrigger = false)
	{
		return $this->deleteCommon($user, $notrigger);
		//return $this->deleteCommon($user, $notrigger, 1);
	}

	/**
	 *  Delete a line of object in database
	 *
	 *	@param  User	$user       User that delete
	 *  @param	int		$idline		Id of line to delete
	 *  @param 	bool 	$notrigger  false=launch triggers after, true=disable triggers
	 *  @return int         		>0 if OK, <0 if KO
	 */
	public function deleteLine(User $user, $idline, $notrigger = false)
	{
		if ($this->status < 0) {
			$this->error = 'ErrorDeleteLineNotAllowedByObjectStatus';
			return -2;
		}

		return $this->deleteLineCommon($user, $idline, $notrigger);
	}


	/**
	 *	Validate object
	 *
	 *	@param		User	$user     		User making status change
	 *  @param		int		$notrigger		1=Does not execute triggers, 0= execute triggers
	 *	@return  	int						<=0 if OK, 0=Nothing done, >0 if KO
	 */
	public function validate($user, $notrigger = 0)
	{
		global $conf, $langs;

		require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

		$error = 0;

		// Protection
		if ($this->status == self::STATUS_VALIDATED) {
			dol_syslog(get_class($this)."::validate action abandonned: already validated", LOG_WARNING);
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->factudata->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->factudata->factudata_advance->validate))))
		 {
		 $this->error='NotEnoughPermissions';
		 dol_syslog(get_class($this)."::valid ".$this->error, LOG_ERR);
		 return -1;
		 }*/

		$now = dol_now();

		$this->db->begin();

		// Define new ref
		if (!$error && (preg_match('/^[\(]?PROV/i', $this->ref) || empty($this->ref))) { // empty should not happened, but when it occurs, the test save life
			$num = $this->getNextNumRef();
		} else {
			$num = $this->ref;
		}
		$this->newref = $num;

		if (!empty($num)) {
			// Validate
			$sql = "UPDATE ".MAIN_DB_PREFIX.$this->table_element;
			$sql .= " SET ref = '".$this->db->escape($num)."',";
			$sql .= " status = ".self::STATUS_VALIDATED;
			if (!empty($this->fields['date_validation'])) {
				$sql .= ", date_validation = '".$this->db->idate($now)."'";
			}
			if (!empty($this->fields['fk_user_valid'])) {
				$sql .= ", fk_user_valid = ".((int) $user->id);
			}
			$sql .= " WHERE rowid = ".((int) $this->id);

			dol_syslog(get_class($this)."::validate()", LOG_DEBUG);
			$resql = $this->db->query($sql);
			if (!$resql) {
				dol_print_error($this->db);
				$this->error = $this->db->lasterror();
				$error++;
			}

			if (!$error && !$notrigger) {
				// Call trigger
				$result = $this->call_trigger('FACTUDATA_VALIDATE', $user);
				if ($result < 0) {
					$error++;
				}
				// End call triggers
			}
		}

		if (!$error) {
			$this->oldref = $this->ref;

			// Rename directory if dir was a temporary ref
			if (preg_match('/^[\(]?PROV/i', $this->ref)) {
				// Now we rename also files into index
				$sql = 'UPDATE '.MAIN_DB_PREFIX."ecm_files set filename = CONCAT('".$this->db->escape($this->newref)."', SUBSTR(filename, ".(strlen($this->ref) + 1).")), filepath = 'factudata/".$this->db->escape($this->newref)."'";
				$sql .= " WHERE filename LIKE '".$this->db->escape($this->ref)."%' AND filepath = 'factudata/".$this->db->escape($this->ref)."' and entity = ".$conf->entity;
				$resql = $this->db->query($sql);
				if (!$resql) {
					$error++; $this->error = $this->db->lasterror();
				}

				// We rename directory ($this->ref = old ref, $num = new ref) in order not to lose the attachments
				$oldref = dol_sanitizeFileName($this->ref);
				$newref = dol_sanitizeFileName($num);
				$dirsource = $conf->doafip->dir_output.'/factudata/'.$oldref;
				$dirdest = $conf->doafip->dir_output.'/factudata/'.$newref;
				if (!$error && file_exists($dirsource)) {
					dol_syslog(get_class($this)."::validate() rename dir ".$dirsource." into ".$dirdest);

					if (@rename($dirsource, $dirdest)) {
						dol_syslog("Rename ok");
						// Rename docs starting with $oldref with $newref
						$listoffiles = dol_dir_list($conf->doafip->dir_output.'/factudata/'.$newref, 'files', 1, '^'.preg_quote($oldref, '/'));
						foreach ($listoffiles as $fileentry) {
							$dirsource = $fileentry['name'];
							$dirdest = preg_replace('/^'.preg_quote($oldref, '/').'/', $newref, $dirsource);
							$dirsource = $fileentry['path'].'/'.$dirsource;
							$dirdest = $fileentry['path'].'/'.$dirdest;
							@rename($dirsource, $dirdest);
						}
					}
				}
			}
		}

		// Set new ref and current status
		if (!$error) {
			$this->ref = $num;
			$this->status = self::STATUS_VALIDATED;
		}

		if (!$error) {
			$this->db->commit();
			return 1;
		} else {
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *	Set draft status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, >0 if OK
	 */
	public function setDraft($user, $notrigger = 0)
	{
		// Protection
		if ($this->status <= self::STATUS_DRAFT) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->doafip_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_DRAFT, $notrigger, 'FACTUDATA_UNVALIDATE');
	}

	/**
	 *	Set cancel status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function cancel($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_VALIDATED) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->doafip_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_CANCELED, $notrigger, 'FACTUDATA_CANCEL');
	}

	/**
	 *	Set back to validated status
	 *
	 *	@param	User	$user			Object user that modify
	 *  @param	int		$notrigger		1=Does not execute triggers, 0=Execute triggers
	 *	@return	int						<0 if KO, 0=Nothing done, >0 if OK
	 */
	public function reopen($user, $notrigger = 0)
	{
		// Protection
		if ($this->status != self::STATUS_CANCELED) {
			return 0;
		}

		/*if (! ((empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->write))
		 || (! empty($conf->global->MAIN_USE_ADVANCED_PERMS) && ! empty($user->rights->doafip->doafip_advance->validate))))
		 {
		 $this->error='Permission denied';
		 return -1;
		 }*/

		return $this->setStatusCommon($user, self::STATUS_VALIDATED, $notrigger, 'FACTUDATA_REOPEN');
	}

	/**
	 *  Return a link to the object card (with optionaly the picto)
	 *
	 *  @param  int     $withpicto                  Include picto in link (0=No picto, 1=Include picto into link, 2=Only picto)
	 *  @param  string  $option                     On what the link point to ('nolink', ...)
	 *  @param  int     $notooltip                  1=Disable tooltip
	 *  @param  string  $morecss                    Add more css on link
	 *  @param  int     $save_lastsearch_value      -1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
	 *  @return	string                              String with URL
	 */
	public function getNomUrl($withpicto = 0, $option = '', $notooltip = 0, $morecss = '', $save_lastsearch_value = -1)
	{
		global $conf, $langs, $hookmanager;

		if (!empty($conf->dol_no_mouse_hover)) {
			$notooltip = 1; // Force disable tooltips
		}

		$result = '';

		$label = img_picto('', $this->picto).' <u>'.$langs->trans("FactuData").'</u>';
		if (isset($this->status)) {
			$label .= ' '.$this->getLibStatut(5);
		}
		$label .= '<br>';
		$label .= '<b>'.$langs->trans('Ref').':</b> '.$this->ref;

		$url = dol_buildpath('/doafip/factudata_card.php', 1).'?id='.$this->id;

		if ($option != 'nolink') {
			// Add param to save lastsearch_values or not
			$add_save_lastsearch_values = ($save_lastsearch_value == 1 ? 1 : 0);
			if ($save_lastsearch_value == -1 && preg_match('/list\.php/', $_SERVER["PHP_SELF"])) {
				$add_save_lastsearch_values = 1;
			}
			if ($add_save_lastsearch_values) {
				$url .= '&save_lastsearch_values=1';
			}
		}

		$linkclose = '';
		if (empty($notooltip)) {
			if (!empty($conf->global->MAIN_OPTIMIZEFORTEXTBROWSER)) {
				$label = $langs->trans("ShowFactuData");
				$linkclose .= ' alt="'.dol_escape_htmltag($label, 1).'"';
			}
			$linkclose .= ' title="'.dol_escape_htmltag($label, 1).'"';
			$linkclose .= ' class="classfortooltip'.($morecss ? ' '.$morecss : '').'"';
		} else {
			$linkclose = ($morecss ? ' class="'.$morecss.'"' : '');
		}

		if ($option == 'nolink') {
			$linkstart = '<span';
		} else {
			$linkstart = '<a href="'.$url.'"';
		}
		$linkstart .= $linkclose.'>';
		if ($option == 'nolink') {
			$linkend = '</span>';
		} else {
			$linkend = '</a>';
		}

		$result .= $linkstart;

		if (empty($this->showphoto_on_popup)) {
			if ($withpicto) {
				$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
			}
		} else {
			if ($withpicto) {
				require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

				list($class, $module) = explode('@', $this->picto);
				$upload_dir = $conf->$module->multidir_output[$conf->entity]."/$class/".dol_sanitizeFileName($this->ref);
				$filearray = dol_dir_list($upload_dir, "files");
				$filename = $filearray[0]['name'];
				if (!empty($filename)) {
					$pospoint = strpos($filearray[0]['name'], '.');

					$pathtophoto = $class.'/'.$this->ref.'/thumbs/'.substr($filename, 0, $pospoint).'_mini'.substr($filename, $pospoint);
					if (empty($conf->global->{strtoupper($module.'_'.$class).'_FORMATLISTPHOTOSASUSERS'})) {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><div class="photoref"><img class="photo'.$module.'" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div></div>';
					} else {
						$result .= '<div class="floatleft inline-block valignmiddle divphotoref"><img class="photouserphoto userphoto" alt="No photo" border="0" src="'.DOL_URL_ROOT.'/viewimage.php?modulepart='.$module.'&entity='.$conf->entity.'&file='.urlencode($pathtophoto).'"></div>';
					}

					$result .= '</div>';
				} else {
					$result .= img_object(($notooltip ? '' : $label), ($this->picto ? $this->picto : 'generic'), ($notooltip ? (($withpicto != 2) ? 'class="paddingright"' : '') : 'class="'.(($withpicto != 2) ? 'paddingright ' : '').'classfortooltip"'), 0, 0, $notooltip ? 0 : 1);
				}
			}
		}

		if ($withpicto != 2) {
			$result .= $this->ref;
		}

		$result .= $linkend;
		//if ($withpicto != 2) $result.=(($addlabel && $this->label) ? $sep . dol_trunc($this->label, ($addlabel > 1 ? $addlabel : 0)) : '');

		global $action, $hookmanager;
		$hookmanager->initHooks(array('factudatadao'));
		$parameters = array('id'=>$this->id, 'getnomurl'=>$result);
		$reshook = $hookmanager->executeHooks('getNomUrl', $parameters, $this, $action); // Note that $action and $object may have been modified by some hooks
		if ($reshook > 0) {
			$result = $hookmanager->resPrint;
		} else {
			$result .= $hookmanager->resPrint;
		}

		return $result;
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLabelStatus($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	/**
	 *  Return the label of the status
	 *
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return	string 			       Label of status
	 */
	public function getLibStatut($mode = 0)
	{
		return $this->LibStatut($this->status, $mode);
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Return the status
	 *
	 *  @param	int		$status        Id status
	 *  @param  int		$mode          0=long label, 1=short label, 2=Picto + short label, 3=Picto, 4=Picto + long label, 5=Short label + Picto, 6=Long label + Picto
	 *  @return string 			       Label of status
	 */
	public function LibStatut($status, $mode = 0)
	{
		// phpcs:enable
		if (empty($this->labelStatus) || empty($this->labelStatusShort)) {
			global $langs;
			//$langs->load("doafip@doafip");
			$this->labelStatus[self::STATUS_DRAFT] = $langs->trans('Draft');
			$this->labelStatus[self::STATUS_VALIDATED] = $langs->trans('Enabled');
			$this->labelStatus[self::STATUS_CANCELED] = $langs->trans('Disabled');
			$this->labelStatusShort[self::STATUS_DRAFT] = $langs->trans('Draft');
			$this->labelStatusShort[self::STATUS_VALIDATED] = $langs->trans('Enabled');
			$this->labelStatusShort[self::STATUS_CANCELED] = $langs->trans('Disabled');
		}

		$statusType = 'status'.$status;
		//if ($status == self::STATUS_VALIDATED) $statusType = 'status1';
		if ($status == self::STATUS_CANCELED) {
			$statusType = 'status6';
		}

		return dolGetStatus($this->labelStatus[$status], $this->labelStatusShort[$status], '', $statusType, $mode);
	}

	/**
	 *	Load the info information in the object
	 *
	 *	@param  int		$id       Id of object
	 *	@return	void
	 */
	public function info($id)
	{
		$sql = 'SELECT rowid, date_creation as datec, tms as datem,';
		$sql .= ' fk_user_creat, fk_user_modif';
		$sql .= ' FROM '.MAIN_DB_PREFIX.$this->table_element.' as t';
		$sql .= ' WHERE t.rowid = '.((int) $id);
		$result = $this->db->query($sql);
		if ($result) {
			if ($this->db->num_rows($result)) {
				$obj = $this->db->fetch_object($result);
				$this->id = $obj->rowid;
				if ($obj->fk_user_author) {
					$cuser = new User($this->db);
					$cuser->fetch($obj->fk_user_author);
					$this->user_creation = $cuser;
				}

				if ($obj->fk_user_valid) {
					$vuser = new User($this->db);
					$vuser->fetch($obj->fk_user_valid);
					$this->user_validation = $vuser;
				}

				if ($obj->fk_user_cloture) {
					$cluser = new User($this->db);
					$cluser->fetch($obj->fk_user_cloture);
					$this->user_cloture = $cluser;
				}

				$this->date_creation     = $this->db->jdate($obj->datec);
				$this->date_modification = $this->db->jdate($obj->datem);
				$this->date_validation   = $this->db->jdate($obj->datev);
			}

			$this->db->free($result);
		} else {
			dol_print_error($this->db);
		}
	}

	/**
	 * Initialise object with example values
	 * Id must be 0 if object instance is a specimen
	 *
	 * @return void
	 */
	public function initAsSpecimen()
	{
		// Set here init that are not commonf fields
		// $this->property1 = ...
		// $this->property2 = ...

		$this->initAsSpecimenCommon();
	}

	/**
	 * 	Create an array of lines
	 *
	 * 	@return array|int		array of lines if OK, <0 if KO
	 */
	public function getLinesArray()
	{
		$this->lines = array();

		$objectline = new FactuDataLine($this->db);
		$result = $objectline->fetchAll('ASC', 'position', 0, 0, array('customsql'=>'fk_factudata = '.((int) $this->id)));

		if (is_numeric($result)) {
			$this->error = $this->error;
			$this->errors = $this->errors;
			return $result;
		} else {
			$this->lines = $result;
			return $this->lines;
		}
	}

	/**
	 *  Returns the reference to the following non used object depending on the active numbering module.
	 *
	 *  @return string      		Object free reference
	 */
	public function getNextNumRef()
	{
		global $langs, $conf;
		$langs->load("doafip@doafip");

		if (empty($conf->global->DOAFIP_FACTUDATA_ADDON)) {
			$conf->global->DOAFIP_FACTUDATA_ADDON = 'mod_factudata_standard';
		}

		if (!empty($conf->global->DOAFIP_FACTUDATA_ADDON)) {
			$mybool = false;

			$file = $conf->global->DOAFIP_FACTUDATA_ADDON.".php";
			$classname = $conf->global->DOAFIP_FACTUDATA_ADDON;

			// Include file with class
			$dirmodels = array_merge(array('/'), (array) $conf->modules_parts['models']);
			foreach ($dirmodels as $reldir) {
				$dir = dol_buildpath($reldir."core/modules/doafip/");

				// Load file with numbering class (if found)
				$mybool |= @include_once $dir.$file;
			}

			if ($mybool === false) {
				dol_print_error('', "Failed to include file ".$file);
				return '';
			}

			if (class_exists($classname)) {
				$obj = new $classname();
				$numref = $obj->getNextValue($this);

				if ($numref != '' && $numref != '-1') {
					return $numref;
				} else {
					$this->error = $obj->error;
					//dol_print_error($this->db,get_class($this)."::getNextNumRef ".$obj->error);
					return "";
				}
			} else {
				print $langs->trans("Error")." ".$langs->trans("ClassNotFound").' '.$classname;
				return "";
			}
		} else {
			print $langs->trans("ErrorNumberingModuleNotSetup", $this->element);
			return "";
		}
	}

	/**
	 *  Create a document onto disk according to template module.
	 *
	 *  @param	    string		$modele			Force template to use ('' to not force)
	 *  @param		Translate	$outputlangs	objet lang a utiliser pour traduction
	 *  @param      int			$hidedetails    Hide details of lines
	 *  @param      int			$hidedesc       Hide description
	 *  @param      int			$hideref        Hide ref
	 *  @param      null|array  $moreparams     Array to provide more information
	 *  @return     int         				0 if KO, 1 if OK
	 */
	public function generateDocument($modele, $outputlangs, $hidedetails = 0, $hidedesc = 0, $hideref = 0, $moreparams = null)
	{
		global $conf, $langs;

		$result = 0;
		$includedocgeneration = 0;

		$langs->load("doafip@doafip");

		if (!dol_strlen($modele)) {
			$modele = 'standard_factudata';

			if (!empty($this->model_pdf)) {
				$modele = $this->model_pdf;
			} elseif (!empty($conf->global->FACTUDATA_ADDON_PDF)) {
				$modele = $conf->global->FACTUDATA_ADDON_PDF;
			}
		}

		$modelpath = "core/modules/doafip/doc/";

		if ($includedocgeneration && !empty($modele)) {
			$result = $this->commonGenerateDocument($modelpath, $modele, $outputlangs, $hidedetails, $hidedesc, $hideref, $moreparams);
		}

		return $result;
	}

	/**
	 * Action executed by scheduler
	 * CAN BE A CRON TASK. In such a case, parameters come from the schedule job setup field 'Parameters'
	 * Use public function doScheduledJob($param1, $param2, ...) to get parameters
	 *
	 * @return	int			0 if OK, <>0 if KO (this function is used also by cron so only 0 is OK)
	 */
	public function doScheduledJob()
	{
		global $conf, $langs;

		//$conf->global->SYSLOG_FILE = 'DOL_DATA_ROOT/dolibarr_mydedicatedlofile.log';

		$error = 0;
		$this->output = '';
		$this->error = '';

		dol_syslog(__METHOD__, LOG_DEBUG);

		$now = dol_now();

		$this->db->begin();

		// ...

		$this->db->commit();

		return $error;
	}


}
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobjectline.class.php';

/**
 * Class FactuDataLine. You can also remove this and generate a CRUD class for lines objects.
 */
class FactuDataLine extends CommonObjectLine
{
	// To complete with content of an object FactuDataLine
	// We should have a field rowid, fk_factudata and position

	/**
	 * @var int  Does object support extrafields ? 0=No, 1=Yes
	 */
	public $isextrafieldmanaged = 0;

	/**
	 * Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	public function __construct(DoliDB $db)
	{
	    $this->db = $db;
	}
	
}
